# SPDX-License-Identifier: GPL-3.0-or-later
"""Compositor N-panel UI."""

import bpy

from .operators import (
    NODE_OT_exr_combine, NODE_OT_exr_remove, NODE_OT_exr_crypto_pick,
    _find_source, _layercake_instances, _settings_signature, crypto_node,
)

_SOURCE_LABEL = {
    "CompositorNodeRLayers": "Render Layers",
    "CompositorNodeImage": "Multilayer EXR",
}


class NODE_PT_exr_combine(bpy.types.Panel):
    bl_label = "LayerCake"
    bl_idname = "NODE_PT_exr_combine"
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = "LayerCake"

    @classmethod
    def poll(cls, context):
        sd = context.space_data
        return sd and getattr(sd, "tree_type", "") == "CompositorNodeTree"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.layercake

        source = _find_source(context)

        # Which LayerCake group does the button act on: the selected instance,
        # else any instance already in this tree.
        tree = getattr(context.space_data, "edit_tree", None)
        existing = _layercake_instances(tree) if tree is not None else []
        active = getattr(context, "active_node", None)
        inst = active if active in existing else next((n for n in existing if n.select), None)
        if inst is None and existing:
            inst = existing[0]

        box = layout.box()
        if source is not None:
            box.label(text=_SOURCE_LABEL.get(source.bl_idname, source.bl_idname), icon="NODE_SEL")
            box.label(text='"%s"' % source.name)
        elif inst is not None:
            box.label(text="LayerCake group", icon="NODETREE")
            box.label(text="select it, then Update / Remove")
        else:
            box.label(text="Select a source node", icon="ERROR")
            box.label(text="Render Layers or multilayer EXR")

        # One contextual button: Bake → Remove (unchanged) / Update (options changed).
        col = layout.column()
        col.scale_y = 1.4
        if inst is None:
            sub = col.column()
            sub.enabled = source is not None
            sub.operator(NODE_OT_exr_combine.bl_idname, text="Bake Combined", icon="NODETREE")
        elif inst.get("lc_sig", "") != _settings_signature(settings):
            col.operator(NODE_OT_exr_combine.bl_idname, text="Update Combined", icon="FILE_REFRESH")
        else:
            col.operator(NODE_OT_exr_remove.bl_idname, text="Remove LayerCake", icon="TRASH")

        # Cryptomatte picking — only shown when a crypto node is actually present.
        # The button switches the viewer to the picker view and activates the
        # node; the matte list is editable here. The actual ＋ eyedropper is a
        # Blender-internal widget that add-ons can't trigger, so that single click
        # happens on the node (its ＋ is visible once the button has activated it).
        crypto_rows = [(k, l) for k, l in (("object", "Object"), ("material", "Material"))
                       if crypto_node(tree, k) is not None]
        if crypto_rows:
            cbox = layout.box()
            cbox.label(text="Cryptomatte", icon="EYEDROPPER")
            for kind, label in crypto_rows:
                cm = crypto_node(tree, kind)
                op = cbox.operator(NODE_OT_exr_crypto_pick.bl_idname,
                                   text="Pick %s" % label, icon="EYEDROPPER")
                op.kind = kind
                cbox.prop(cm, "matte_id", text="IDs")

        opts = layout.column(heading="Options")
        opts.use_property_split = True
        opts.use_property_decorate = False
        opts.prop(settings, "embed_source")
        opts.prop(settings, "auto_enable_passes")
        opts.prop(settings, "include_extras")

        crypto = opts.column(heading="Cryptomatte")
        crypto.prop(settings, "include_crypto_object")
        crypto.prop(settings, "include_crypto_material")

        opts.prop(settings, "film_transparent")
        opts.separator()
        opts.prop(settings, "connect_viewer")
        opts.prop(settings, "set_as_output")


classes = (NODE_PT_exr_combine,)
