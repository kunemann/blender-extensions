import bpy
from mathutils import Vector, Euler, Matrix

from . import default_shapes

TAG = "RB_Tag"
ROOT_COLL = "RenderBones"
FALLBACK_MAT_PREFIX = "RB_Fallback_"

# ---------------- live update ----------------
def _live_update(self, context):
    ob = getattr(context, "object", None)
    if ob and ob.type == 'ARMATURE':
        try:
            restyle_renderables(ob)
        except Exception as e:
            print("[RenderBones] live update:", e)

def _override_to_viewport(self, context):
    """When the user picks an override Display Type, also flip the armature's
    viewport display_type so the on-screen overlay matches."""
    ob = getattr(context, "object", None)
    if ob and ob.type == 'ARMATURE':
        override = getattr(ob.data, "rb_default_shape_override", 'AUTO')
        if override != 'AUTO':
            try:
                ob.data.display_type = override
            except Exception as e:
                print("[RenderBones] viewport sync:", e)

def _convert_default_to_viewport(self, context):
    """Mirror the toggle into Viewport Display > Shapes (inverted): when we're
    overriding with default shapes, hide custom shapes in the viewport too."""
    ob = getattr(context, "object", None)
    if ob and ob.type == 'ARMATURE':
        try:
            ob.data.show_bone_custom_shapes = not ob.data.rb_convert_default_shapes
        except Exception as e:
            print("[RenderBones] show_bone_custom_shapes sync:", e)

# ---------------- Armature properties ----------------
def register_armature_props():
    A = bpy.types.Armature
    A.rb_use_pose_colors = bpy.props.BoolProperty(
        name="Use bone colors",
        description="Use the bone’s Viewport Display color (Bone Color first, Pose Bone Color as fallback). Resolves Custom and Theme Color Sets",
        default=True, update=_live_update)
    A.rb_fallback_color = bpy.props.FloatVectorProperty(
        name="Color",
        description="Fallback color when pose custom colors are disabled",
        subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 1.0, 1.0), update=_live_update)
    A.rb_skin_thickness = bpy.props.FloatProperty(
        name="Thickness",
        description="Uniform tube thickness (Skin modifier)",
        min=0.0, soft_max=0.05, default=0.006, update=_live_update)
    A.rb_use_emission = bpy.props.BoolProperty(
        name="Emission",
        description="Drive shader emission by the bone color",
        default=False, update=_live_update)
    A.rb_emission_strength = bpy.props.FloatProperty(
        name="Emission Strength",
        description="Emission strength",
        min=0.0, soft_max=10.0, default=1.0, update=_live_update)
    A.rb_alpha = bpy.props.FloatProperty(
        name="Alpha",
        description="Material alpha (0..1). Uses blending when < 1",
        min=0.0, max=1.0, default=1.0, update=_live_update)
    A.rb_convert_default_shapes = bpy.props.BoolProperty(
        name="Convert default shapes",
        description="Use the armature's display type (Octahedral/Stick/B-Bone/Envelope/Wire) for ALL bones, ignoring any Custom Bone Shape. Also disables the 'Shapes' option in Viewport Display so the overlay matches",
        default=False, update=_convert_default_to_viewport)
    A.rb_default_shape_override = bpy.props.EnumProperty(
        name="Display Type",
        description="Which default bone shape to use. AUTO follows the armature's viewport display_type. Picking a specific type also updates the armature's viewport display",
        items=[
            ('AUTO', "Auto (use viewport)", "Read armature.display_type"),
            ('OCTAHEDRAL', "Octahedral", ""),
            ('STICK', "Stick", ""),
            ('BBONE', "B-Bone", ""),
            ('ENVELOPE', "Envelope", ""),
            ('WIRE', "Wire", ""),
        ],
        default='AUTO', update=_override_to_viewport)

# ---------------- helpers ----------------
def ensure_root_and_sub_collection(arm_obj):
    scene_root = bpy.context.scene.collection
    root = bpy.data.collections.get(ROOT_COLL)
    if not root:
        root = bpy.data.collections.new(ROOT_COLL)
        scene_root.children.link(root)
        if hasattr(root, "color_tag"):
            try: root.color_tag = 'COLOR_03'
            except Exception: pass

    sub_name = f"RenderBones {arm_obj.name}"
    sub = bpy.data.collections.get(sub_name)
    if not sub:
        sub = bpy.data.collections.new(sub_name)
        root.children.link(sub)
        if hasattr(sub, "color_tag"):
            try: sub.color_tag = 'COLOR_03'  # green
            except Exception: pass
    return sub

def duplicate_object(obj_src, name):
    obj = obj_src.copy()
    if obj_src.data:
        obj.data = obj_src.data.copy()
    obj.name = name
    obj[TAG] = True
    return obj

def make_cube_for_empty(name, empty):
    mesh = bpy.data.meshes.new(f"{name}_Mesh")
    verts = [Vector((x,y,z)) for x in (-0.5,0.5) for y in (-0.5,0.5) for z in (-0.5,0.5)]
    faces = [(0,1,3,2),(4,6,7,5),(0,2,6,4),(1,5,7,3),(0,4,5,1),(2,3,7,6)]
    mesh.from_pydata(verts, [], faces); mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    s = getattr(empty, "empty_display_size", 1.0)
    obj.scale = (s,s,s)
    obj[TAG] = True
    return obj

def bone_target(pb):
    t = getattr(pb, "custom_shape_transform", None)
    return t if t else pb

def shape_local_offset_matrix(pb):
    loc = Vector(getattr(pb, "custom_shape_translation", (0,0,0)))
    rot = Euler(getattr(pb, "custom_shape_rotation_euler", (0,0,0)), 'XYZ')
    if hasattr(pb, "custom_shape_scale_xyz"):
        scl = Vector(pb.custom_shape_scale_xyz)
    else:
        s = float(getattr(pb, "custom_shape_scale", 1.0)); scl = Vector((s,s,s))
    if getattr(pb, "use_custom_shape_bone_size", False):
        scl *= pb.bone.length
    return Matrix.Translation(loc) @ rot.to_matrix().to_4x4() @ Matrix.Diagonal((scl.x, scl.y, scl.z, 1.0))

def is_visible_posebone(arm, pb):
    b = pb.bone
    if getattr(b, "hide", False): return False
    ad = arm.data
    if hasattr(ad, "collections") and hasattr(b, "collections"):  # 4.x
        if len(b.collections) == 0: return True
        for bc in b.collections:
            if not bc: continue
            vis = getattr(bc, "is_visible", None)
            if vis is None:
                vis = getattr(bc, "is_visible_get", lambda: True)()
            if vis: return True
        return False
    if hasattr(ad, "layers") and hasattr(b, "layers"):           # 3.6
        for i in range(min(len(ad.layers), len(b.layers))):
            if ad.layers[i] and b.layers[i]: return True
        return False
    return True

def _get(obj, path):
    cur = obj
    for p in path.split('.'):
        cur = getattr(cur, p, None)
        if cur is None:
            return None
    return cur

def _theme_color_set_color(palette):
    if not palette or not isinstance(palette, str) or not palette.startswith('THEME'):
        return None
    try:
        idx = int(palette[5:]) - 1
    except ValueError:
        return None
    try:
        sets = bpy.context.preferences.themes[0].bone_color_sets
    except (AttributeError, IndexError):
        return None
    if idx < 0 or idx >= len(sets):
        return None
    c = getattr(sets[idx], "normal", None)
    if c is None or len(c) < 3:
        return None
    return (c[0], c[1], c[2])

def _pick_normal_color(color_prop):
    if not color_prop:
        return None
    palette = getattr(color_prop, "palette", None)
    if palette == 'DEFAULT':
        return None
    custom = getattr(color_prop, "custom", None)
    if custom is not None and (palette == 'CUSTOM' or palette == 'CUSTOM_COLOR_SET'):
        c = getattr(custom, "normal", None)
        if c and len(c) >= 3:
            return c
    if palette and isinstance(palette, str) and palette.startswith('THEME'):
        c = _theme_color_set_color(palette)
        if c:
            return c
    c = getattr(color_prop, "normal", None)
    if c and len(c) >= 3:
        return c
    return None

def resolve_effective_color_rgba(pb, use_pose_colors=True, fallback_rgb=(1,1,1)):
    if use_pose_colors and pb:
        b = getattr(pb, "bone", None)
        if b:
            col = _pick_normal_color(getattr(b, "color", None))
            if col: return (col[0], col[1], col[2], col[3] if len(col) > 3 else 1.0)
        col = _pick_normal_color(getattr(pb, "color", None))
        if col: return (col[0], col[1], col[2], col[3] if len(col) > 3 else 1.0)
    return (fallback_rgb[0], fallback_rgb[1], fallback_rgb[2], 1.0)

def _ensure_principled(mat):
    mat.use_nodes = True
    nt = mat.node_tree
    out = nt.nodes.get("Material Output") or nt.nodes.new("ShaderNodeOutputMaterial")
    bsdf = nt.nodes.get("Principled BSDF") or nt.nodes.new("ShaderNodeBsdfPrincipled")
    if not bsdf.outputs[0].is_linked:
        nt.links.new(bsdf.outputs[0], out.inputs[0])
    return bsdf, out

def build_or_update_material(name, rgba, use_emission, strength, alpha):
    mat = bpy.data.materials.get(name)
    if not mat:
        mat = bpy.data.materials.new(name)

    bsdf, _out = _ensure_principled(mat)

    base_rgba = (float(rgba[0]), float(rgba[1]), float(rgba[2]), 1.0)

    if bsdf.inputs.get("Base Color"):
        bsdf.inputs["Base Color"].default_value = base_rgba
    elif bsdf.inputs.get("base_color"):
        bsdf.inputs["base_color"].default_value = base_rgba

    if hasattr(mat, "diffuse_color"):
        mat.diffuse_color = base_rgba

    if use_emission:
        for key in ("Emission Color", "Emission", "emission_color", "Color"):
            sock = bsdf.inputs.get(key)
            if sock and hasattr(sock, "default_value"):
                if len(sock.default_value) == 3:
                    sock.default_value[:] = base_rgba[:3]
                else:
                    sock.default_value = base_rgba
                break
        for key in ("Emission Strength", "Strength", "emission_strength"):
            if bsdf.inputs.get(key):
                bsdf.inputs[key].default_value = float(strength)
                break
    else:
        for key in ("Emission Strength", "Strength", "emission_strength"):
            if bsdf.inputs.get(key):
                bsdf.inputs[key].default_value = 0.0
                break

    if bsdf.inputs.get("Alpha"):
        bsdf.inputs["Alpha"].default_value = float(alpha)
    if alpha < 1.0:
        if hasattr(mat, "blend_method"): mat.blend_method = 'BLEND'
        if hasattr(mat, "use_backface_culling"): mat.use_backface_culling = False
        if hasattr(mat, "shadow_method"): mat.shadow_method = 'HASHED'
    else:
        if hasattr(mat, "blend_method"): mat.blend_method = 'OPAQUE'
        if hasattr(mat, "use_backface_culling"): mat.use_backface_culling = True
        if hasattr(mat, "shadow_method"): mat.shadow_method = 'OPAQUE'

    for key in ("Specular","Specular IOR Level","SpecularIORLevel","specular"):
        if bsdf.inputs.get(key):
            bsdf.inputs[key].default_value = 0.2
            break
    return mat

def ensure_fallback_material_for_armature(arm):
    rgb = tuple(getattr(arm.data, "rb_fallback_color", (1,1,1)))
    name = FALLBACK_MAT_PREFIX + arm.name
    return build_or_update_material(
        name,
        (rgb[0], rgb[1], rgb[2], 1.0),
        getattr(arm.data, "rb_use_emission", False),
        getattr(arm.data, "rb_emission_strength", 1.0),
        getattr(arm.data, "rb_alpha", 1.0),
    )

def ensure_armature_modifier(obj, arm, bone_name):
    mod = obj.modifiers.get("Armature") or obj.modifiers.new("Armature", 'ARMATURE')
    mod.object = arm; mod.use_vertex_groups = True
    if obj.data and hasattr(obj.data, "vertices"):
        vg = obj.vertex_groups.get(bone_name) or obj.vertex_groups.new(name=bone_name)
        vg.add(range(len(obj.data.vertices)), 1.0, 'REPLACE')
    mod.show_viewport = False; mod.show_render = False

def apply_scale_to_delta(obj):
    sx,sy,sz = obj.scale
    dsx,dsy,dsz = obj.delta_scale
    obj.delta_scale = (dsx*sx, dsy*sy, dsz*sz)
    obj.scale = (1,1,1)

def mesh_to_curve(obj):
    """Replace a mesh object with a new curve object by tracing edge chains."""
    if obj.type != 'MESH': return obj
    me = obj.data
    verts = me.vertices
    if len(verts) == 0 or len(me.edges) == 0: return obj

    adj = {i: set() for i in range(len(verts))}
    for e in me.edges:
        adj[e.vertices[0]].add(e.vertices[1])
        adj[e.vertices[1]].add(e.vertices[0])

    visited = set()
    chains = []
    for start_v in range(len(verts)):
        if start_v in visited or not adj[start_v]:
            continue
        chain = [start_v]
        visited.add(start_v)
        cur = start_v
        while True:
            nxt = None
            for n in adj[cur]:
                if n not in visited:
                    nxt = n
                    break
            if nxt is None:
                break
            chain.append(nxt)
            visited.add(nxt)
            cur = nxt
        if len(chain) > 1:
            chains.append(chain)

    curve_data = bpy.data.curves.new(me.name, 'CURVE')
    curve_data.dimensions = '3D'
    for chain in chains:
        sp = curve_data.splines.new('POLY')
        sp.points.add(len(chain) - 1)
        for i, vi in enumerate(chain):
            co = verts[vi].co
            sp.points[i].co = (co.x, co.y, co.z, 1.0)
        if chain[0] in adj.get(chain[-1], set()):
            sp.use_cyclic_u = True

    new_obj = bpy.data.objects.new(obj.name + "_tmp", curve_data)
    new_obj.parent = obj.parent
    new_obj.parent_type = obj.parent_type
    new_obj.parent_bone = obj.parent_bone
    new_obj.matrix_parent_inverse = obj.matrix_parent_inverse.copy()
    new_obj.matrix_world = obj.matrix_world.copy()  # MUST be last (parent resets it)
    if hasattr(obj, "delta_scale"):
        new_obj.delta_scale = obj.delta_scale[:]
    if hasattr(obj, "inherit_scale"):
        new_obj.inherit_scale = obj.inherit_scale
    for key in obj.keys():
        new_obj[key] = obj[key]
    for col in obj.users_collection:
        col.objects.link(new_obj)
    old_name = obj.name
    bpy.data.objects.remove(obj, do_unlink=True)
    bpy.data.meshes.remove(me)
    new_obj.name = old_name
    return new_obj

def ensure_curve(obj):
    """Make sure object is a curve. Returns the (possibly new) object."""
    if obj.type == 'CURVE': return obj
    if obj.type in {'SURFACE', 'META', 'FONT'}:
        dg = bpy.context.evaluated_depsgraph_get()
        me = obj.evaluated_get(dg).to_mesh(preserve_all_data_layers=True, depsgraph=dg)
        me.name = f"{obj.name}_MeshData"
        obj.data = me; obj.type = 'MESH'
    if obj.type == 'MESH':
        return mesh_to_curve(obj)
    return obj

def ensure_curve_thickness(obj, radius):
    """Give curve objects renderable thickness via bevel_depth."""
    if obj.type != 'CURVE': return
    obj.data.bevel_depth = float(max(0.0, radius))
    obj.data.use_fill_caps = True
    obj.data.bevel_resolution = 4

def mesh_shade_smooth(obj):
    if not obj or obj.type != 'MESH' or not obj.data: return
    try:
        for p in obj.data.polygons: p.use_smooth = True
    except Exception:
        pass
    angle = 1.22173
    if hasattr(obj.data, "use_auto_smooth"):
        # Blender 3.x
        obj.data.use_auto_smooth = True
        if hasattr(obj.data, "auto_smooth_angle"):
            obj.data.auto_smooth_angle = angle
    else:
        # Blender 4.x+ — add Smooth by Angle modifier directly
        mod = obj.modifiers.get("RB_SmoothByAngle")
        if not mod:
            mod = obj.modifiers.new("RB_SmoothByAngle", 'NODES')
            node_group = bpy.data.node_groups.get("Smooth by Angle")
            if not node_group:
                # Create it via a temp object in scene collection, then reuse
                try:
                    tmp = bpy.data.objects.new("_rb_tmp", bpy.data.meshes.new("_rb_tmp"))
                    bpy.context.scene.collection.objects.link(tmp)
                    vl = bpy.context.view_layer
                    prev_act = vl.objects.active
                    vl.objects.active = tmp; tmp.select_set(True)
                    bpy.ops.object.shade_smooth_by_angle(angle=angle)
                    for m in tmp.modifiers:
                        if m.type == 'NODES' and m.node_group:
                            node_group = m.node_group
                            break
                    vl.objects.active = prev_act
                    bpy.data.objects.remove(tmp, do_unlink=True)
                except Exception:
                    pass
            if node_group:
                mod.node_group = node_group
        if mod and mod.node_group:
            for item in mod.node_group.interface.items_tree:
                if getattr(item, "identifier", "") and "Angle" in item.name:
                    try: mod[item.identifier] = angle
                    except Exception: pass

def needs_flip(obj):
    try:
        return obj.matrix_world.to_3x3().determinant() < 0.0
    except Exception:
        return False

def ensure_flipfix(obj):
    m = obj.modifiers.get("RB_FlipNormals")
    if needs_flip(obj):
        if not m: m = obj.modifiers.new("RB_FlipNormals", 'SOLIDIFY')
        m.thickness = 0.0; m.use_flip_normals = True; m.offset = 1.0
        m.show_viewport = True; m.show_render = True
    else:
        if m: obj.modifiers.remove(m)

def ensure_wireframe(obj, thickness):
    """Use Wireframe modifier to make mesh edges renderable while preserving shape."""
    if obj.type != 'MESH': return
    wf = obj.modifiers.get("RB_Wireframe") or obj.modifiers.new("RB_Wireframe", 'WIREFRAME')
    wf.thickness = float(max(0.0, thickness))
    wf.use_even_offset = True
    wf.use_replace = True
    wf.show_viewport = True; wf.show_render = True
    mesh_shade_smooth(obj)

def convert_armature(arm, wm, log, selected_bones=None):
    sub = ensure_root_and_sub_collection(arm)
    if selected_bones:
        pbs = selected_bones
    else:
        pbs = list(arm.pose.bones)
    n = max(1, len(pbs))

    use_pose_colors = getattr(arm.data, "rb_use_pose_colors", True)
    fallback_rgb = tuple(getattr(arm.data, "rb_fallback_color", (1,1,1)))
    thickness = getattr(arm.data, "rb_skin_thickness", 0.006)
    use_emission = getattr(arm.data, "rb_use_emission", False)
    emi_strength = getattr(arm.data, "rb_emission_strength", 1.0)
    alpha = getattr(arm.data, "rb_alpha", 1.0)
    convert_default = getattr(arm.data, "rb_convert_default_shapes", False)
    override = getattr(arm.data, "rb_default_shape_override", 'AUTO')
    fallback_mat = ensure_fallback_material_for_armature(arm)

    target_names = {f"{arm.name}_{pb.name}_CS" for pb in pbs}
    for obj in list(sub.objects):
        if obj.get(TAG, False) and obj.name in target_names:
            data = obj.data
            bpy.data.objects.remove(obj, do_unlink=True)
            if data and data.users == 0:
                if isinstance(data, bpy.types.Curve): bpy.data.curves.remove(data)
                elif isinstance(data, bpy.types.Mesh): bpy.data.meshes.remove(data)

    for i, pb in enumerate(pbs):
        wm.progress_update(i / n)
        if not pb.bone or pb.bone.length <= 1e-6: continue
        if not is_visible_posebone(arm, pb): continue

        src = pb.custom_shape
        if convert_default:
            use_default = True
        elif src is None:
            continue
        else:
            use_default = False

        tgt = bone_target(pb)
        name = f"{arm.name}_{pb.name}_CS"

        if use_default:
            display_type = arm.data.display_type if override == 'AUTO' else override
            obj = default_shapes.make_default_shape_object(name, pb, display_type)
            if obj is None: continue
            obj[TAG] = True
        elif src.type in {'MESH','CURVE','SURFACE','META','FONT'}:
            obj = duplicate_object(src, name)
        elif src.type == 'EMPTY':
            obj = make_cube_for_empty(name, src)
        else:
            obj = duplicate_object(src, name)
        if obj.name not in [o.name for o in sub.objects]:
            sub.objects.link(obj)

        obj.hide_set(False); obj.hide_viewport = False; obj.hide_render = False
        if hasattr(obj, "inherit_scale"): obj.inherit_scale = 'FULL'

        obj.parent = arm; obj.parent_type = 'BONE'; obj.parent_bone = tgt.name
        parent_world = arm.matrix_world @ tgt.matrix
        obj.matrix_parent_inverse = parent_world.inverted()
        if use_default:
            obj.matrix_world = parent_world
        else:
            obj.matrix_world = parent_world @ shape_local_offset_matrix(pb)

        obj = ensure_curve(obj)

        if obj.data:
            rgba = resolve_effective_color_rgba(pb, use_pose_colors, fallback_rgb)
            name_mat = f"RB_{arm.name}_{pb.name}_Mat" if use_pose_colors else fallback_mat.name
            mat = build_or_update_material(name_mat, rgba, use_emission, emi_strength, alpha)
            if len(obj.data.materials) == 0: obj.data.materials.append(mat)
            else: obj.data.materials[0] = mat
            obj.color = (float(rgba[0]), float(rgba[1]), float(rgba[2]), float(rgba[3]) if len(rgba) > 3 else 1.0)

        scl = obj.scale
        avg_scl = (abs(scl[0]) + abs(scl[1]) + abs(scl[2])) / 3.0
        adjusted = thickness / avg_scl if avg_scl > 0 else thickness
        ensure_curve_thickness(obj, adjusted)

        obj[TAG] = True
        if obj.data: obj.data.name = f"{name}_Data"
        obj["rb_armature"] = arm.name; obj["rb_bone"] = tgt.name

        log.append(f"{arm.name}: {pb.name} -> {obj.name}")

def rebuild_renderables(arm):
    """Regenerate all RB curves for an armature. Used by live-update on geometry properties."""
    if not arm.pose: return
    wm = bpy.context.window_manager
    log = []
    try:
        wm.progress_begin(0, 1)
    except Exception:
        pass
    try:
        convert_armature(arm, wm, log, selected_bones=None)
    finally:
        try: wm.progress_end()
        except Exception: pass

def restyle_renderables(arm):
    sub = bpy.data.collections.get(f"RenderBones {arm.name}")
    if not sub: return 0
    use_pose_colors = getattr(arm.data, "rb_use_pose_colors", True)
    fallback_rgb = tuple(getattr(arm.data, "rb_fallback_color", (1,1,1)))
    thickness = getattr(arm.data, "rb_skin_thickness", 0.006)
    use_emission = getattr(arm.data, "rb_use_emission", False)
    emi_strength = getattr(arm.data, "rb_emission_strength", 1.0)
    alpha = getattr(arm.data, "rb_alpha", 1.0)
    fallback_mat = ensure_fallback_material_for_armature(arm)

    count = 0
    for obj in sub.objects:
        if not obj.get(TAG, False): continue

        if obj.data:
            pb = arm.pose.bones.get(obj.get("rb_bone","")) if obj.get("rb_bone") else None
            rgba = resolve_effective_color_rgba(pb, use_pose_colors, fallback_rgb)
            name_mat = f"RB_{arm.name}_{pb.name}_Mat" if (use_pose_colors and pb) else fallback_mat.name
            mat = build_or_update_material(name_mat, rgba, use_emission, emi_strength, alpha)
            if len(obj.data.materials) == 0: obj.data.materials.append(mat)
            else: obj.data.materials[0] = mat
            obj.color = (float(rgba[0]), float(rgba[1]), float(rgba[2]), float(rgba[3]) if len(rgba) > 3 else 1.0)

        obj = ensure_curve(obj)
        scl = obj.scale
        avg_scl = (abs(scl[0]) + abs(scl[1]) + abs(scl[2])) / 3.0
        adjusted = thickness / avg_scl if avg_scl > 0 else thickness
        ensure_curve_thickness(obj, adjusted)
        count += 1
    return count

class RB_OT_convert(bpy.types.Operator):
    bl_idname = "rb.convert_custom_shapes"
    bl_label = "Convert Custom Bone Shapes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        arms = [context.object] if context.object and context.object.type == 'ARMATURE' else []
        if not arms:
            self.report({'WARNING'}, "Select an Armature.")
            return {'CANCELLED'}
        wm = context.window_manager; wm.progress_begin(0,1)
        log = []
        selected_bones = None
        if context.mode == 'POSE':
            arm = context.object
            sel = [pb for pb in arm.pose.bones if getattr(pb, "select", False)]
            if sel:
                selected_bones = sel
        try:
            for arm in arms:
                if not arm.pose: continue
                convert_armature(arm, wm, log, selected_bones=selected_bones)
        finally:
            wm.progress_end()
        for line in log: print("[RenderBones]", line)
        self.report({'INFO'}, f"Done. {len(log)} shapes processed.")
        return {'FINISHED'}

class RB_PT_sidebar(bpy.types.Panel):
    bl_label = "RenderBones"
    bl_idname = "RB_PT_sidebar"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "RenderBones"

    def draw(self, context):
        lay = self.layout
        ob = context.object
        lay.operator("rb.convert_custom_shapes", icon='OUTLINER_OB_ARMATURE')
        if not ob or ob.type != 'ARMATURE':
            lay.label(text="Select an Armature.", icon='ARMATURE_DATA')
            return
        arm = ob

        box = lay.box(); box.label(text=f"Rig: {arm.name}")

        row = box.row()
        row.prop(arm.data, "rb_use_pose_colors")
        if not arm.data.rb_use_pose_colors:
            box.prop(arm.data, "rb_fallback_color", text="Color")

        box.prop(arm.data, "rb_skin_thickness")

        box = lay.box()
        box.prop(arm.data, "rb_use_emission")
        col = box.column(); col.active = arm.data.rb_use_emission
        col.prop(arm.data, "rb_emission_strength")
        box.prop(arm.data, "rb_alpha")

        box = lay.box()
        box.label(text="Default Shapes (v2.0)", icon='BONE_DATA')
        box.prop(arm.data, "rb_convert_default_shapes")
        sub_col = box.column()
        sub_col.active = arm.data.rb_convert_default_shapes
        sub_col.prop(arm.data, "rb_default_shape_override")
        sub_col.label(text=f"Viewport: {arm.data.display_type}", icon='ARMATURE_DATA')

classes = (RB_OT_convert, RB_PT_sidebar)

def register():
    register_armature_props()
    for c in classes:
        bpy.utils.register_class(c)

def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    A = bpy.types.Armature
    del A.rb_use_pose_colors
    del A.rb_fallback_color
    del A.rb_skin_thickness
    del A.rb_use_emission
    del A.rb_emission_strength
    del A.rb_alpha
    del A.rb_convert_default_shapes
    del A.rb_default_shape_override
