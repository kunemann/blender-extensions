import bpy
from math import cos, sin, pi
from mathutils import Vector, Matrix

OCTAHEDRAL_NECK_FRAC = 0.1
OCTAHEDRAL_NECK_HALF = 0.1
END_SPHERE_RADIUS_FRAC = 0.04
END_SPHERE_LONGS = 8
END_SPHERE_LATS = 6


def _new_curve_object(name, verts, edges):
    cu = bpy.data.curves.new(f"{name}_Curve", 'CURVE')
    cu.dimensions = '3D'
    for a, b in edges:
        sp = cu.splines.new('POLY')
        sp.points.add(1)
        va = verts[a]
        vb = verts[b]
        sp.points[0].co = (va[0], va[1], va[2], 1.0)
        sp.points[1].co = (vb[0], vb[1], vb[2], 1.0)
    return bpy.data.objects.new(name, cu)


def _octahedral_verts_edges(length):
    L = length
    # Blender's octahedral: wide ring near the HEAD (at y = 0.1*L). The bone
    # tapers from a small head-pyramid up to the ring, then a long taper to
    # the tail point.
    n = OCTAHEDRAL_NECK_FRAC * L
    h = OCTAHEDRAL_NECK_HALF * L
    verts = [
        (0, 0, 0),
        (0, L, 0),
        ( h, n,  h),
        (-h, n,  h),
        (-h, n, -h),
        ( h, n, -h),
    ]
    edges = [
        (0,2),(0,3),(0,4),(0,5),
        (1,2),(1,3),(1,4),(1,5),
        (2,3),(3,4),(4,5),(5,2),
    ]
    return verts, edges


def _add_end_spheres(verts, edges, length, radius_frac=END_SPHERE_RADIUS_FRAC,
                     longs=END_SPHERE_LONGS, lats=END_SPHERE_LATS):
    """Append small wireframe spheres at the head (y=0) and tail (y=length)
    to mirror Blender's joint-marker dots on Stick/Octahedral display."""
    r = radius_frac * length
    for center in ((0, 0, 0), (0, length, 0)):
        sv, se = _uv_sphere_wireframe(center, r, longs, lats)
        offset = len(verts)
        verts.extend(sv)
        edges.extend([(a + offset, b + offset) for a, b in se])


def make_octahedral_curve(name, length):
    verts, edges = _octahedral_verts_edges(length)
    _add_end_spheres(verts, edges, length)
    return _new_curve_object(name, verts, edges)


def make_stick_curve(name, length, with_spheres=True):
    verts = [(0, 0, 0), (0, length, 0)]
    edges = [(0, 1)]
    if with_spheres:
        _add_end_spheres(verts, edges, length)
    return _new_curve_object(name, verts, edges)


def make_bbone_curve(name, pb, length):
    bone = pb.bone
    bx = getattr(bone, "bbone_x", 0.1) or 0.1
    bz = getattr(bone, "bbone_z", 0.1) or 0.1
    segments = max(1, getattr(bone, "bbone_segments", 1))

    if segments == 1:
        verts = [
            (-bx, 0,     -bz), ( bx, 0,     -bz),
            ( bx, 0,      bz), (-bx, 0,      bz),
            (-bx, length, -bz), ( bx, length,-bz),
            ( bx, length,  bz), (-bx, length, bz),
        ]
        edges = [
            (0,1),(1,2),(2,3),(3,0),
            (4,5),(5,6),(6,7),(7,4),
            (0,4),(1,5),(2,6),(3,7),
        ]
        return _new_curve_object(name, verts, edges)

    seg_len = length / segments
    rect_local = [
        Vector((-bx, 0, -bz)),
        Vector(( bx, 0, -bz)),
        Vector(( bx, 0,  bz)),
        Vector((-bx, 0,  bz)),
    ]

    verts = []
    edges = []
    for i in range(segments + 1):
        if i < segments:
            try:
                M_local = pb.bbone_segment_matrix(i, rest=False)
            except Exception:
                M_local = Matrix.Translation((0, i * seg_len, 0))
        else:
            try:
                M_last = pb.bbone_segment_matrix(segments - 1, rest=False)
                M_local = M_last @ Matrix.Translation((0, seg_len, 0))
            except Exception:
                M_local = Matrix.Translation((0, segments * seg_len, 0))

        base_idx = len(verts)
        for v in rect_local:
            verts.append(tuple(M_local @ v))

        edges.extend([
            (base_idx + 0, base_idx + 1),
            (base_idx + 1, base_idx + 2),
            (base_idx + 2, base_idx + 3),
            (base_idx + 3, base_idx + 0),
        ])
        if i > 0:
            prev = base_idx - 4
            for k in range(4):
                edges.append((prev + k, base_idx + k))

    return _new_curve_object(name, verts, edges)


def _uv_sphere_wireframe(center, radius, longs=12, lats=8):
    cx, cy, cz = center
    verts = []
    edges = []
    top_idx = 0
    bot_idx = 1
    verts.append((cx, cy + radius, cz))
    verts.append((cx, cy - radius, cz))

    ring_indices = []
    for r in range(1, lats):
        phi = pi * r / lats
        y = cy + radius * cos(phi)
        rr = radius * sin(phi)
        ring = []
        for s in range(longs):
            theta = 2 * pi * s / longs
            ring.append(len(verts))
            verts.append((cx + rr * cos(theta), y, cz + rr * sin(theta)))
        ring_indices.append(ring)
        for s in range(longs):
            edges.append((ring[s], ring[(s + 1) % longs]))

    for s in range(longs):
        prev = top_idx
        for r in ring_indices:
            edges.append((prev, r[s]))
            prev = r[s]
        edges.append((prev, bot_idx))

    return verts, edges


def make_envelope_curve(name, pb, length):
    bone = pb.bone
    hr = max(1e-6, getattr(bone, "head_radius", 0.1))
    tr = max(1e-6, getattr(bone, "tail_radius", 0.1))
    longs = 12
    lats = 8

    verts = []
    edges = []

    head_v, head_e = _uv_sphere_wireframe((0, 0, 0), hr, longs, lats)
    head_offset = len(verts)
    verts.extend(head_v)
    edges.extend([(a + head_offset, b + head_offset) for a, b in head_e])

    tail_v, tail_e = _uv_sphere_wireframe((0, length, 0), tr, longs, lats)
    tail_offset = len(verts)
    verts.extend(tail_v)
    edges.extend([(a + tail_offset, b + tail_offset) for a, b in tail_e])

    tube_head_ring = []
    tube_tail_ring = []
    for s in range(longs):
        theta = 2 * pi * s / longs
        tube_head_ring.append(len(verts))
        verts.append((hr * cos(theta), 0, hr * sin(theta)))
    for s in range(longs):
        theta = 2 * pi * s / longs
        tube_tail_ring.append(len(verts))
        verts.append((tr * cos(theta), length, tr * sin(theta)))

    for s in range(longs):
        edges.append((tube_head_ring[s], tube_head_ring[(s + 1) % longs]))
        edges.append((tube_tail_ring[s], tube_tail_ring[(s + 1) % longs]))
        edges.append((tube_head_ring[s], tube_tail_ring[s]))

    return _new_curve_object(name, verts, edges)


def make_default_shape_object(name, pb, display_type):
    L = pb.bone.length
    if L <= 1e-6:
        return None
    dt = (display_type or 'OCTAHEDRAL').upper()
    if dt == 'STICK':
        return make_stick_curve(name, L, with_spheres=True)
    if dt == 'WIRE':
        return make_stick_curve(name, L, with_spheres=False)
    if dt == 'BBONE':
        return make_bbone_curve(name, pb, L)
    if dt == 'ENVELOPE':
        return make_envelope_curve(name, pb, L)
    return make_octahedral_curve(name, L)
